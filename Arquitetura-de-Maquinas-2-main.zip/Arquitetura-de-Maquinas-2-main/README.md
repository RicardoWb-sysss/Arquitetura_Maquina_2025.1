# Arquitetura-de-Maquinas-2
## projeto facimp 2025 por
Lucas Bandeira
Maycon Douglas
Ricardo Emnu
Gabriel Tosca
João Paulo
